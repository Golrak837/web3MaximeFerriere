const Exercice = (props) => {
    return (
      <p>
        {props.part} {props.exo}
      </p>
    );
  };

  export default Exercice;